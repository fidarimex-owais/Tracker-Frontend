// frontend/src/App.jsx

import {
  BrowserRouter,
  Route,
  Routes,
} from 'react-router-dom';

import { AuthProvider } from './auth/AuthContext';
import { ThemeProvider } from './theme/ThemeContext';
import ProtectedRoute from './auth/ProtectedRoute';
import AppErrorBoundary from './components/AppErrorBoundary';
import LandingPage from './pages/LandingPage';
import PortalLayout from './layouts/PortalLayout';

import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';

import AdminDashboard from './pages/admin/AdminDashboard';
import CreateId from './pages/admin/CreateId';
import SignupRequests from './pages/admin/SignupRequests';
import UserManagement from './pages/admin/UserManagement';
import AdminQrScanner from './pages/admin/AdminQrScanner';
import AdminBarcodeScanner from './pages/admin/AdminBarcodeScanner';
import QrBrandDetails from './pages/admin/QrBrandDetails';
import IdentityDocuments from './pages/admin/IdentityDocuments';

import SubAdminDashboard from './pages/subadmin/SubAdminDashboard';
import VendorDashboard from './pages/vendor/VendorDashboard';
import SupervisorDashboard from './pages/supervisor/SupervisorDashboard';
import QRCodeGenerator from './pages/QRCodeGenerator';
import RecoverySheet from './pages/recovery/RecoverySheet';
import Profile from './pages/profile/Profile';
import HelpCenter from './pages/HelpCenter';
import NotFound from './pages/NotFound';
import ServerError from './pages/ServerError';

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <AuthProvider>
          <AppErrorBoundary>
            <Routes>
              <Route
                path="/login"
                element={<Login />}
              />

              <Route
                path="/signup"
                element={<Signup />}
              />

              <Route
                path="/"
                element={<LandingPage />}
              />

              <Route
                path="/500"
                element={<ServerError />}
              />

              <Route
                element={
                  <ProtectedRoute roles={['admin']} />
                }
              >
                <Route
                  path="/admin"
                  element={<PortalLayout />}
                >
                  <Route
                    index
                    element={<AdminDashboard />}
                  />

                  <Route
                    path="create-id"
                    element={<CreateId />}
                  />

                  <Route
                    path="users"
                    element={<UserManagement />}
                  />

                  <Route
                    path="identity-documents"
                    element={<IdentityDocuments />}
                  />

                  <Route
                    path="signup-requests"
                    element={<SignupRequests />}
                  />

                  <Route
                    path="qr-generator"
                    element={<QRCodeGenerator />}
                  />

                  <Route
                    path="qr-scanner"
                    element={<AdminQrScanner />}
                  />

                  <Route
                    path="qr-brand-details"
                    element={<QrBrandDetails />}
                  />

                  <Route
                    path="barcode-scanner"
                    element={<AdminBarcodeScanner />}
                  />

                  <Route
                    path="recovery-sheets"
                    element={<RecoverySheet />}
                  />

                  <Route
                    path="profile"
                    element={<Profile />}
                  />

                  <Route
                    path="help"
                    element={<HelpCenter />}
                  />
                </Route>
              </Route>

              <Route
                element={
                  <ProtectedRoute roles={['subadmin']} />
                }
              >
                <Route
                  path="/sub-admin"
                  element={<PortalLayout />}
                >
                  <Route
                    index
                    element={<SubAdminDashboard />}
                  />

                  <Route
                    path="create-id"
                    element={<CreateId />}
                  />

                  <Route
                    path="signup-requests"
                    element={<SignupRequests />}
                  />

                  <Route
                    path="users"
                    element={<UserManagement />}
                  />

                  <Route
                    path="qr-generator"
                    element={<QRCodeGenerator />}
                  />

                  <Route
                    path="qr-scanner"
                    element={<AdminQrScanner />}
                  />

                  <Route
                    path="barcode-scanner"
                    element={<AdminBarcodeScanner />}
                  />

                  <Route
                    path="recovery-sheets"
                    element={<RecoverySheet />}
                  />

                  <Route
                    path="profile"
                    element={<Profile />}
                  />

                  <Route
                    path="help"
                    element={<HelpCenter />}
                  />
                </Route>
              </Route>

              <Route
                element={
                  <ProtectedRoute roles={['vendor']} />
                }
              >
                <Route
                  path="/vendor"
                  element={<PortalLayout />}
                >
                  <Route
                    index
                    element={<VendorDashboard />}
                  />

                  <Route
                    path="create-id"
                    element={<CreateId />}
                  />

                  <Route
                    path="signup-requests"
                    element={<SignupRequests />}
                  />

                  <Route
                    path="users"
                    element={<UserManagement />}
                  />

                  <Route
                    path="barcode-scanner"
                    element={<AdminBarcodeScanner />}
                  />

                  <Route
                    path="recovery-sheets"
                    element={<RecoverySheet />}
                  />

                  <Route
                    path="profile"
                    element={<Profile />}
                  />

                  <Route
                    path="help"
                    element={<HelpCenter />}
                  />
                </Route>
              </Route>

              <Route
                element={
                  <ProtectedRoute roles={['supervisor']} />
                }
              >
                <Route
                  path="/supervisor"
                  element={<PortalLayout />}
                >
                  <Route
                    index
                    element={<SupervisorDashboard />}
                  />

                  <Route
                    path="barcode-scanner"
                    element={<AdminBarcodeScanner />}
                  />

                  <Route
                    path="profile"
                    element={<Profile />}
                  />

                  <Route
                    path="help"
                    element={<HelpCenter />}
                  />
                </Route>
              </Route>

              <Route
                path="*"
                element={<NotFound />}
              />
            </Routes>
          </AppErrorBoundary>
        </AuthProvider>
      </BrowserRouter>
    </ThemeProvider>
  );
}
